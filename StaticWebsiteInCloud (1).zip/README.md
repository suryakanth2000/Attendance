# Static Website Hosting in AWS S3

## Overview
This project demonstrates how to host a static website using Amazon S3.

## Steps

1. **Create an S3 Bucket**
   - Go to AWS S3 console.
   - Click 'Create bucket' and name it (e.g., `my-static-site`).
   - Uncheck 'Block all public access'.

2. **Upload Files**
   - Upload `index.html`, `about.html`, and `styles.css`.

3. **Enable Static Website Hosting**
   - Go to Properties > Static website hosting.
   - Enable and set index document to `index.html`.

4. **Set Permissions**
   - Go to Permissions > Bucket Policy:
     ```
     {
       "Version": "2012-10-17",
       "Statement": [
         {
           "Sid": "PublicReadGetObject",
           "Effect": "Allow",
           "Principal": "*",
           "Action": "s3:GetObject",
           "Resource": "arn:aws:s3:::your-bucket-name/*"
         }
       ]
     }
     ```

5. **Access the Website**
   - Use the endpoint URL from the S3 bucket settings.

Enjoy your hosted site!
